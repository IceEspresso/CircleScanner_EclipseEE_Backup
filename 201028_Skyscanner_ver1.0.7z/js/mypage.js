/*
    링크를 클릭하면 클릭한 그 요소의 href속성의 값을 변수 tabTarget에 저장
    저장된 값에서 #을 삭제한다.
    tabTarget = tab1
*/
const targetLink = document.querySelectorAll(".user-info a");
const tabContent = document.querySelectorAll(".user-contents__wrap > div");
console.log(tabContent);
//let orgTarget = "#tab1"; // a.replace('b','c');
targetLink.forEach(function (tabLink) {
  tabLink.addEventListener("click", (e) => {
    //console.log(tabLink);
    //console.log(e.currentTarget);
    // 속성을 가져오는 메소드 getAttribute
    e.preventDefault(); // 기본 속성을 막음
    let orgTarget = e.currentTarget.getAttribute("href");
    //console.log("orgTarget======" + orgTarget);
    const tabTarget = orgTarget.replace("#", "");

    tabContent.forEach((x) => {
      x.style.display = "none";
    });
    document.getElementById(tabTarget).style.display = "block";

    targetLink.forEach((z) => {
      z.classList.remove("current");
      e.currentTarget.classList.add("current");
    });
  });
});
document.getElementById("tab1").style.display = "block";
