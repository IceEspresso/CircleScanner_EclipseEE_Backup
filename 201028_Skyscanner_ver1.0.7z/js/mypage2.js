/*
    링크를 클릭하면 클릭한 그 요소의 href속성의 값을 변수 tabTarget에 저장
    저장된 값에서 #을 삭제한다.
    tabTarget = tab1
*/
const targetLink = document.querySelectorAll(".user-info a");
const tabContent = document.querySelectorAll(".user-contents__wrap > div");
console.log(tabContent);
//let orgTarget = "#tab1"; // a.replace('b','c');
targetLink.forEach(function (tabLink) {
  tabLink.addEventListener("click", (e) => {
    //console.log(tabLink);
    //console.log(e.currentTarget);
    // 속성을 가져오는 메소드 getAttribute
    e.preventDefault(); // 기본 속성을 막음
    // console.log(e.currentTarget);

    targetLink.forEach((z) => {
      z.classList.remove("current");
      e.currentTarget.classList.add("current");

      tabContent.forEach(function (j) {
        console.log(j);

        if (e.currentTarget.classList.contains("current")) {
          j.classList.add("current");
        }
        if (e.currentTarget.classList != "current") {
          j.classList.remove("current");
        }
      });
    });
    // tabContent.forEach(function (j) {
    //   console.log(j);
    //   console.log(j.classList == "user-contents current");
    //   // if (j.classList == "user-contents current") {
    //   //   j.classList.remove("current");
    //   // } else {
    //   //   j.classList.add("current");
    //   // }
    //   //if(j.classList)
    //   // console.log(tabContentSelect);
    //   // if (tabContentSelect) {
    //   //   j.classList.remove("current");
    //   // }
    // });
  });
});
