/* modal-login */
const modal = document.querySelector(".login");
const modalClose = document.querySelector(".login__modal-close");
const loginModal = document.querySelector(".login__modal");
const loginModalContents = document.querySelector(".login__modal-contents");

modal.addEventListener("click", function () {
  loginModal.style.display = "block";
  loginModalContents.style.display = "block";
});

modalClose.addEventListener("click", function () {
  loginModal.style.display = "none";
  loginModalContents.style.display = "none";
});

/* modal-location search */
function modal_location(id) {
  const zIndex = 10;
  const modal_location = document.getElementById(id);
  const bg = document.createElement("div");
  bg.setStyle({
    position: "fixed",
    zIndex: zIndex,
    left: "0px",
    top: "0px",
    width: "100%",
    height: "100%",
    overflow: "auto",
    backgroundColor: "rgba(0,0,0,0.4)",
  });
  document.body.append(bg);

  modal_location
    .querySelector(".modal__close")
    .addEventListener("click", function () {
      bg.remove();
      modal_location.style.display = "none";
    });

  modal_location.setStyle({
    position: "fixed",
    display: "block",
    boxShadow:
      "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
    zIndex: zIndex + 1,
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    msTransform: "translate(-50%, -50%)",
    webkitTransform: "translate(-50%, -50%)",
  });

  $(".city_list a").on("click", function () {
    bg.remove();
    modal_location.style.display = "none";
  });
}

Element.prototype.setStyle = function (styles) {
  for (var k in styles) this.style[k] = styles[k];
  return this;
};

$("#departure").on("click", function () {
  modal_location("my_modal_hb");
  $(".city_list a").on("click", function () {
    var aa = $(this).text();
    if ($("#departure").val().length == 0) {
      $("#departure").val(aa);
    }
  });
});

$("#destination").on("click", function () {
  modal_location("my_modal_hb");
  $(".city_list a").on("click", function () {
    var bb = $(this).text();
    if ($("#destination").val().length == 0) {
      $("#destination").val(bb);
    }
  });
});

/* modal - passengerSeats */
function passengerSeats__modal(id) {
  const zIndex = 9999;
  const passengerSeats__modal = document.getElementById(id);
  // 모달 div 뒤에 희끄무레한 레이어
  const bg = document.createElement("div");
  bg.setStyle({
    position: "fixed",
    zIndex: zIndex,
    left: "0px",
    top: "0px",
    width: "100%",
    height: "100%",
    overflow: "auto",
    // 레이어 색갈은 여기서 바꾸면 됨
    backgroundColor: "rgba(0,0,0,0.4)",
  });
  document.body.append(bg);
  // 닫기 버튼 처리, 시꺼먼 레이어와 모달 div 지우기
  passengerSeats__modal
    .querySelector(".modal_close_btn")
    .addEventListener("click", function () {
      //값넘기고 모달창끄기
      //var seatGradeVal = document.getElementById('popup_open_btn_seatGrade');
      //seatGradeVal.value = Integer.parseInt(adult_n) + Integer.parseInt(kid_n) +"승객,"
      bg.remove();
      passengerSeats__modal.style.display = "none";
    });

  passengerSeats__modal.setStyle({
    position: "fixed",
    display: "block",
    boxShadow:
      "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
    // 시꺼먼 레이어 보다 한칸 위에 보이기
    zIndex: zIndex + 1,
    // div center 정렬
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    msTransform: "translate(-50%, -50%)",
    webkitTransform: "translate(-50%, -50%)",
  });
}
// Element 에 style 한번에 오브젝트로 설정하는 함수 추가
Element.prototype.setStyle = function (styles) {
  for (let k in styles) this.style[k] = styles[k];
  return this;
};

document
  .getElementById("popup_open_btn_seatGrade")
  .addEventListener("click", function () {
    // 모달창 띄우기
    passengerSeats__modal("my_modal");
  });

/* modal - passengerSeats 모달창 내부사항 */
//btn mapping
const minus_a = document.getElementById("minus_adult");
const plus_a = document.getElementById("plus_adult");
const minus_k = document.getElementById("minus_kid");
const plus_k = document.getElementById("plus_kid");
//span mapping
let adult_n = document.getElementById("adult_number");
let kid_n = document.getElementById("kid_number");
//init number
let Adult_initNum = 1;
let kid_initNum = 0;

minus_a.addEventListener("click", function () {
  if (adult_n.innerText == 1) {
    Adult_initNum = 1;
  } else {
    Adult_initNum--;
  }
  adult_n.innerText = Adult_initNum;
});
plus_a.addEventListener("click", function () {
  if (adult_n.innerText == 8) {
    Adult_initNum = 8;
  } else {
    Adult_initNum++;
  }
  adult_n.innerText = Adult_initNum;
});

minus_k.addEventListener("click", function () {
  if (kid_n.innerText == 0) {
    kid_initNum = 0;
  } else {
    kid_initNum--;
  }
  kid_n.innerText = kid_initNum;
});
plus_k.addEventListener("click", function () {
  if (kid_n.innerText == 8) {
    kid_initNum = 8;
  } else {
    kid_initNum++;
  }
  kid_n.innerText = kid_initNum;
});

/* Q&A */
const accordionBtn = document.querySelectorAll(".board__title");
const acoordionText = document.querySelectorAll(".board__contents");

accordionBtn.forEach((el) => {
  el.addEventListener("click", toggleAccordion);
});

function toggleAccordion(el) {
  const targetText = el.currentTarget.nextElementSibling.classList;

  if (targetText.contains("active")) {
    targetText.remove("active");
  } else {
    targetText.add("active");
  }
}
