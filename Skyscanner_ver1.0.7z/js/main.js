const accordionBtn  = document.querySelectorAll('.board__title');
const acoordionText = document.querySelectorAll('.board__contents');

accordionBtn.forEach( function(el) {

    el.addEventListener('click', toggleAccordion);

});

function toggleAccordion(el) {
    
    const targetText = el.currentTarget.nextElementSibling.classList;
    
    if(targetText.contains('active')) {
        targetText.remove('active');
    }
    else {
        targetText.add('active');
    }
    
};

